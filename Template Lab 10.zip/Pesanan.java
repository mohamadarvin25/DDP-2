public class Pesanan implements Comparable<Pesanan> {
    // TODO: tambahkan attributes

    public Pesanan(String nama, int harga, int prioritas) {
        // TODO: Lengkapi Constructor berikut

    }

    @Override
    public int compareTo(Pesanan o) {
        // TODO: Lengkapi method ini
        return 0;
    }

    // Tambahkan getter-setter bila diperlukan
}