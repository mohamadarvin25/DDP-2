// Ikuti UML diagram

public class Minuman extends Pesanan {
    // TODO: tambahkan attributes

    public Minuman(String nama, int harga, int prioritas, boolean isPakeEs) {
        // TODO: Lengkapi Constructor berikut

    }

    @Override
    public String toString() {
        // TODO: return deskripsi sesuai dengan ketentuan soal
        return "";
    }

    // Tambahkan getter-setter bila diperlukan
}
