public class DaftarPesanan<T extends Pesanan> {
    // TODO: tambahkan attributes

    public DaftarPesanan() {
        // TODO: Lengkapi Constructor berikut

    }

    public void tambahPesanan(T pesanan) {
        // TODO: proses tambah pesanan

    }

    public T nextPesanan() {
        // TODO: return sesuai dengan urutan prioritas
        return null;
    }

    // Tambahkan getter-setter apabila diperlukan

}
