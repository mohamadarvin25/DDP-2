// Ikuti UML Diagram

public class Makanan extends Pesanan {
    // TODO: tambahkan attributes

    public Makanan(String nama, int harga, int prioritas, int tingkatKepedasan) {
        // TODO: Lengkapi Constructor berikut

    }

    @Override
    public String toString() {
        // TODO: return deskripsi sesuai dengan ketentuan soal
        return "";
    }

    // Tambahkan getter-setter apabila diperlukan
}
