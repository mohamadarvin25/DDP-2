public class Listrik { // TODO: implementasikan sesuai UML diagram
    // TODO: tambahkan method-method yang diperlukan
  
}