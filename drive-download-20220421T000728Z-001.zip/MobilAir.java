public class MobilAir extends Mobil { //TODO: impelementasikan sesuai UML diagram
  
    public MobilAir(String nama, EngineBehaviour engineBehaviour, String bahanBakar){
        // TODO: Lengkapi constructor berikut
    }

    // TODO: Lengkapi method ini
    @Override
    public String isiBahanBakar(){
        return "";
    }

    // TODO: Lengkapi method ini
    @Override
    public String[] simulasi(){
        return null;
    }   
}