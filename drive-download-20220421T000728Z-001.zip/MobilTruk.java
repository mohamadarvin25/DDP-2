public class MobilTruk extends Mobil{ //TODO: impelementasikan sesuai UML diagram

    public MobilTruk(String nama, EngineBehaviour engineBehaviour, String bahanBakar) {
        // TODO: Lengkapi Constructor berikut
    }

    // TODO: Lengkapi method ini
    @Override
    public String isiBahanBakar(){
        return "";
    }

    // TODO: Lengkapi method ini
    @Override
    public String[] simulasi(){
        return null;
    }


}