public class BBM { // TODO: implementasikan sesuai UML diagram
    // TODO: tambahkan method-method yang diperlukan
  
}